typedef enum {false, true} bool;
extern int __VERIFIER_nondet_int(void);
int main() {
    int x3;
    int x3post;
    int x0;
    int x0post;
    int x4;
    int x4post;
    int x1;
    int x1post;
    int x5;
    int x5post;
    int x2;
    int x2post;
    x3 = __VERIFIER_nondet_int();
    x0 = __VERIFIER_nondet_int();
    x4 = __VERIFIER_nondet_int();
    x1 = __VERIFIER_nondet_int();
    x5 = __VERIFIER_nondet_int();
    x2 = __VERIFIER_nondet_int();
    while ((x3 > 0 && -1+x5 > 0 && x2 > 0 && 1+x1 > 0 && x0 > 0 && x4 > 0)) {
        x0post = -1+x0;
        x1post = 1+x1;
        x5post = x4;
        x2post = x3;
        x0 = x0post;
        x1 = x1post;
        x5 = x5post;
        x2 = x2post;
    }
    return 0;
}

