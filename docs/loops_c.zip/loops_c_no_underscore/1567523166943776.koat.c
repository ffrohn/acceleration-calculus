typedef enum {false, true} bool;
extern int __VERIFIER_nondet_int(void);
int main() {
    int x6;
    int x6post;
    int x3;
    int x3post;
    int x0;
    int x0post;
    int x7;
    int x7post;
    int x4;
    int x4post;
    int x1;
    int x1post;
    int x8;
    int x8post;
    int x5;
    int x5post;
    int x2;
    int x2post;
    x6 = __VERIFIER_nondet_int();
    x3 = __VERIFIER_nondet_int();
    x0 = __VERIFIER_nondet_int();
    x7 = __VERIFIER_nondet_int();
    x4 = __VERIFIER_nondet_int();
    x1 = __VERIFIER_nondet_int();
    x8 = __VERIFIER_nondet_int();
    x5 = __VERIFIER_nondet_int();
    x2 = __VERIFIER_nondet_int();
    while ((-x2+x7 <= 0 && -1+x0 > 0 && -2+x2 > 0 && -x2+x3 <= 0 && 2-x2+x4 <= 0 && x8 > 0 && x5 > 0 && -2+x7 > 0 && -2-x5+x3 <= 0 && x4 > 0 && -x5+x4 <= 0 && x6 > 0 && -2-x5+x7 <= 0 && x8-x6 <= 0 && -2+x3 > 0)) {
        x6post = x8;
        x0post = x3;
        x5post = x4;
        x2post = x7;
        x6 = x6post;
        x0 = x0post;
        x5 = x5post;
        x2 = x2post;
    }
    return 0;
}

