typedef enum {false, true} bool;
extern int __VERIFIER_nondet_int(void);
int main() {
    int x3;
    int x3post;
    int x0;
    int x0post;
    int x1;
    int x1post;
    int x2;
    int x2post;
    x3 = __VERIFIER_nondet_int();
    x0 = __VERIFIER_nondet_int();
    x1 = __VERIFIER_nondet_int();
    x2 = __VERIFIER_nondet_int();
    while (1+x1-x3 <= 0) {
        x1post = 1+x1;
        x1 = x1post;
    }
    return 0;
}

