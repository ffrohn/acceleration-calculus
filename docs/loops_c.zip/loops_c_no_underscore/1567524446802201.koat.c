typedef enum {false, true} bool;
extern int __VERIFIER_nondet_int(void);
int main() {
    int x3;
    int x3post;
    int x11;
    int x11post;
    int x0;
    int x0post;
    int x7;
    int x7post;
    int x4;
    int x4post;
    int x12;
    int x12post;
    int x1;
    int x1post;
    int x8;
    int x8post;
    int x5;
    int x5post;
    int x2;
    int x2post;
    int x10;
    int x10post;
    int x6;
    int x6post;
    int x9;
    int x9post;
    x3 = __VERIFIER_nondet_int();
    x11 = __VERIFIER_nondet_int();
    x0 = __VERIFIER_nondet_int();
    x7 = __VERIFIER_nondet_int();
    x4 = __VERIFIER_nondet_int();
    x12 = __VERIFIER_nondet_int();
    x1 = __VERIFIER_nondet_int();
    x8 = __VERIFIER_nondet_int();
    x5 = __VERIFIER_nondet_int();
    x2 = __VERIFIER_nondet_int();
    x10 = __VERIFIER_nondet_int();
    x6 = __VERIFIER_nondet_int();
    x9 = __VERIFIER_nondet_int();
    while ((x4-x3 == 0 && -x0 <= 0 && 2-x9 <= 0 && x10-x2 == 0 && -x7 <= 0)) {
        x0post = -1+x0;
        x7post = 1+x7;
        x0 = x0post;
        x7 = x7post;
    }
    return 0;
}

