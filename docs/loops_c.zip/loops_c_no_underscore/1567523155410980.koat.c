typedef enum {false, true} bool;
extern int __VERIFIER_nondet_int(void);
int main() {
    int x14;
    int x14post;
    int x11;
    int x11post;
    int x0;
    int x0post;
    int x5;
    int x5post;
    int x8;
    int x8post;
    int x2;
    int x2post;
    int x12;
    int x12post;
    int x1;
    int x1post;
    int x6;
    int x6post;
    int x9;
    int x9post;
    int x3;
    int x3post;
    int x13;
    int x13post;
    int x10;
    int x10post;
    int x4;
    int x4post;
    int x7;
    int x7post;
    x14 = __VERIFIER_nondet_int();
    x11 = __VERIFIER_nondet_int();
    x0 = __VERIFIER_nondet_int();
    x5 = __VERIFIER_nondet_int();
    x8 = __VERIFIER_nondet_int();
    x2 = __VERIFIER_nondet_int();
    x12 = __VERIFIER_nondet_int();
    x1 = __VERIFIER_nondet_int();
    x6 = __VERIFIER_nondet_int();
    x9 = __VERIFIER_nondet_int();
    x3 = __VERIFIER_nondet_int();
    x13 = __VERIFIER_nondet_int();
    x10 = __VERIFIER_nondet_int();
    x4 = __VERIFIER_nondet_int();
    x7 = __VERIFIER_nondet_int();
    while ((3-x9+x8 <= 0 && x0-x14 <= 0 && 3+x13-x9 <= 0 && -3+x11 > 0 && 3-x9+x0 <= 0 && -x4+x3 > 0 && x0 > 0 && 1+x3 > 0 && -x9+x11 <= 0 && x14 > 0 && -3+x9 > 0)) {
        x14post = x0;
        x9post = x11;
        x4post = 1+x4;
        x14 = x14post;
        x9 = x9post;
        x4 = x4post;
    }
    return 0;
}

