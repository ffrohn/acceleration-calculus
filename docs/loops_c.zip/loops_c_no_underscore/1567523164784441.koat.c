typedef enum {false, true} bool;
extern int __VERIFIER_nondet_int(void);
int main() {
    int x4;
    int x4post;
    int x11;
    int x11post;
    int x0;
    int x0post;
    int x8;
    int x8post;
    int x5;
    int x5post;
    int x2;
    int x2post;
    int x1;
    int x1post;
    int x9;
    int x9post;
    int x6;
    int x6post;
    int x3;
    int x3post;
    int x10;
    int x10post;
    int x7;
    int x7post;
    x4 = __VERIFIER_nondet_int();
    x11 = __VERIFIER_nondet_int();
    x0 = __VERIFIER_nondet_int();
    x8 = __VERIFIER_nondet_int();
    x5 = __VERIFIER_nondet_int();
    x2 = __VERIFIER_nondet_int();
    x1 = __VERIFIER_nondet_int();
    x9 = __VERIFIER_nondet_int();
    x6 = __VERIFIER_nondet_int();
    x3 = __VERIFIER_nondet_int();
    x10 = __VERIFIER_nondet_int();
    x7 = __VERIFIER_nondet_int();
    while ((-2+x9 > 0 && -x9+x8 <= 0 && -2+x8 > 0 && x5-x0 > 0)) {
        x0post = 1+x0;
        x9post = x8;
        x0 = x0post;
        x9 = x9post;
    }
    return 0;
}

