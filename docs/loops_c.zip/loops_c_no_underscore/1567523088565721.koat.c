typedef enum {false, true} bool;
extern int __VERIFIER_nondet_int(void);
int main() {
    int x0;
    int x0post;
    int x1;
    int x1post;
    x0 = __VERIFIER_nondet_int();
    x1 = __VERIFIER_nondet_int();
    while ((-1+x0 > 0 && x1 > 0 && x1-x0 < 0)) {
        x0post = -1+x0;
        x1post = 1+x1;
        x0 = x0post;
        x1 = x1post;
    }
    return 0;
}

