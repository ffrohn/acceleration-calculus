typedef enum {false, true} bool;
extern int __VERIFIER_nondet_int(void);
int main() {
    int x0;
    int x0post;
    int x1;
    int x1post;
    int x2;
    int x2post;
    x0 = __VERIFIER_nondet_int();
    x1 = __VERIFIER_nondet_int();
    x2 = __VERIFIER_nondet_int();
    while (x1 > 0) {
        x1post = -1+x1;
        x1 = x1post;
    }
    return 0;
}

