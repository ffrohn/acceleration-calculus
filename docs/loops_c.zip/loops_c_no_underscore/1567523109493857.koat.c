typedef enum {false, true} bool;
extern int __VERIFIER_nondet_int(void);
int main() {
    int x3;
    int x3post;
    int x0;
    int x0post;
    int x1;
    int x1post;
    int x2;
    int x2post;
    x3 = __VERIFIER_nondet_int();
    x0 = __VERIFIER_nondet_int();
    x1 = __VERIFIER_nondet_int();
    x2 = __VERIFIER_nondet_int();
    while ((x2 > 0 && -x0+x3 <= 0 && -2+x0 > 0 && 1+x1 > 0 && 4+x2-x0 <= 0 && -2+x3 > 0)) {
        x0post = x3;
        x1post = 10+x1;
        x2post = -1+x2;
        x0 = x0post;
        x1 = x1post;
        x2 = x2post;
    }
    return 0;
}

